import { startPumpSettingsSynchronization, startSynchronization } from ".";

startSynchronization();
startPumpSettingsSynchronization();
