'use strict';

$(document).ready(function() {
	console.log('Application got ready event');
	window.Nightscout.foodclient();
});
